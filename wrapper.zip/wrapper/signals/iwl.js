<?xml version="1.0" encoding="UTF-8"?>
<Error>
  <Code>NoSuchKey</Code>
  <Message>The specified key does not exist.</Message>
  <RequestId>69974730FC4F3F3731A41D31</RequestId>
  <HostId>ppgameres.oss-cn-hongkong.aliyuncs.com</HostId>
  <Key>signals/iwl.js</Key>
  <EC>0026-00000001</EC>
  <RecommendDoc>https://api.aliyun.com/troubleshoot?q=0026-00000001</RecommendDoc>
</Error>
