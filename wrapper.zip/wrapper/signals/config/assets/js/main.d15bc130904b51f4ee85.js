<?xml version="1.0" encoding="UTF-8"?>
<Error>
  <Code>NoSuchKey</Code>
  <Message>The specified key does not exist.</Message>
  <RequestId>6997474930856F3336016935</RequestId>
  <HostId>ppgameres.oss-cn-hongkong.aliyuncs.com</HostId>
  <Key>signals/config/assets/js/main.d15bc130904b51f4ee85.js</Key>
  <EC>0026-00000001</EC>
  <RecommendDoc>https://api.aliyun.com/troubleshoot?q=0026-00000001</RecommendDoc>
</Error>
